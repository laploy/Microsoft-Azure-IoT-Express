﻿/*
    MIB course loy vanich laploy@gmail.com
    Device SIM receiving a message from IoT Hub
*/

using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using System;
using System.Text;

namespace simulated_device
{
    class SimulatedDevice
    {
        private static DeviceClient s_deviceClient;
        private readonly static string s_connectionString = "HostName=loyiothub1.azure-devices.net;DeviceId=loy-iot-device-1;SharedAccessKey=1aq5j0oop5tucSUco8GJ8SNuWCYV5P6hzrW0zc/YhuY=";
        private static async void ReceiveC2dAsync()
        {
            Console.WriteLine("\nReceiving cloud to device messages from service");
            while (true)
            {
                Message receivedMessage = await s_deviceClient.ReceiveAsync();
                if (receivedMessage == null) continue;

                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Received message: {0}",
                Encoding.ASCII.GetString(receivedMessage.GetBytes()));
                Console.ResetColor();

                // Notifies IoT Hub that the message has been successfully processed
                await s_deviceClient.CompleteAsync(receivedMessage);
            }
        }

        private static void Main(string[] args)
        {
            // Connect to the IoT hub using the MQTT protocol
            s_deviceClient = DeviceClient.CreateFromConnectionString(
                s_connectionString, 
                TransportType.Mqtt);
            ReceiveC2dAsync();
            Console.ReadLine();
        }
    }
}



