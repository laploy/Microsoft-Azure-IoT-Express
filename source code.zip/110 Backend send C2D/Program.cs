﻿/*
    MIB course loy vanich laploy@gmail.com
    backend send message to device and
    get acknowlage from device
*/

using Microsoft.Azure.Devices;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Program
    {
        static ServiceClient serviceClient;
        static string connectionString = "HostName=loyiothub1.azure-devices.net;SharedAccessKeyName=service;SharedAccessKey=KCyf3omKkmWncXuKDWdFTjM1edMKKOnMIxBWRoWgmAw=";

        private async static Task SendCloudToDeviceMessageAsync()
        {
            var commandMessage = new
             Message(Encoding.ASCII.GetBytes(DateTime.Now + " Hello from backend"));
            commandMessage.Ack = DeliveryAcknowledgement.Full;
            await serviceClient.SendAsync("loy-iot-device-1", commandMessage);
        }
        private async static void ReceiveFeedbackAsync()
        {
            var feedbackReceiver = serviceClient.GetFeedbackReceiver();

            Console.WriteLine("Receiving c2d feedback from service");
            while (true)
            {
                var feedbackBatch = await feedbackReceiver.ReceiveAsync();
                if (feedbackBatch == null) continue;

                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Received feedback: {0}",
                  string.Join(", ", feedbackBatch.Records.Select(f => f.StatusCode)));
                Console.ResetColor();

                await feedbackReceiver.CompleteAsync(feedbackBatch);
            }
        }
        static void Main(string[] args)
        {
            serviceClient = ServiceClient.CreateFromConnectionString(connectionString);
            ReceiveFeedbackAsync();
            Console.WriteLine("Press any key to send a C2D message.");
            Console.ReadLine();
            SendCloudToDeviceMessageAsync().Wait();
            Console.ReadLine();
        }
    }
}
