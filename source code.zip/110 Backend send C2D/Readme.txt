﻿.NET Core console application
Backend app send message to device
